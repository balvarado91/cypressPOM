//this is a Module
//add import to tbe able to use in other files
export class TodoPage{
    navigate(){
        cy.visit('http://todomvc-app-for-testing.surge.sh/')
    }
    addTodo(todoText){
        cy.get('.new-todo').type(todoText + "{enter}")
    }
    toggleTodo(todoIndex){
        cy.get(`.todo-list li:nth-child(${todoIndex + 1}) .toggle`).click()
    }
    validateTodoTxt(todoIndex, expectedText){
        //Strings interpolation
        cy.get(`.todo-list li:nth-child(${todoIndex + 1}) label`).should('have.text', expectedText)
    }
    clearCompleted() {
        cy.contains('Clear completed').click()
    }
    validateTodoCompletedState(todoIndex, shouldBeCompleted) {
        const line = cy.get(`.todo-list li:nth-child(${todoIndex + 1}) label`)
        line.should(`${shouldBeCompleted ? '' : 'not.'}have.css`, 'text-decoration-line', 'line-through')
    }
    validateNumberOfTodosShown(expectedNumberOfTodos) {
        cy.get('.todo-list li').should('have.length', expectedNumberOfTodos)
    }
}
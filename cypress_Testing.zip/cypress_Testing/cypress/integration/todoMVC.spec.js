/// <reference types="cypress" />

//Regroup test Suite
describe('toDo action', () => {
    beforeEach(() => {
        cy.visit('http://todomvc-app-for-testing.surge.sh/')
    })
    
    it('should be able to add a new todo the list, to prepare coffee ', () => {
        cy.visit('http://todomvc-app-for-testing.surge.sh/');
        cy.get('.new-todo').type("Line the basket of your coffee maker with a filter. Grind coffee beans to medium or medium-fine grind size. Bring filtered water to a boil, then let it sit for a minute.{enter}")
        cy.get('.new-todo').type("Pour enough water into the filter to wet it completely, and let it drain into your cup or coffee pot. Discard the water.{enter}")
        cy.get('.new-todo', {timeout:6000}).type("Measure the ground coffee into the wet filter. Pour in enough water to wet the ground beans and drain into your cup or coffee pot, then pour in the rest of the water {enter}")
        cy.get(':nth-child(1) > .view > .toggle').click();
    })
    it('should validate my code', () =>{
        //validaciones
        cy.get('.new-todo').type("Line the basket.{enter}");
        cy.get('label').should('have.text', 'Line the basket.');
        cy.get('.toggle').should('not.be.checked')
        //clicking toggle
        cy.get('.toggle').click();
        cy.get('label').should('have.css', 'text-decoration-line', 'line-through')
        //cy.get('todo-list').should('not.have.descendants', 'li');
    })
    
    it('should clear all', () =>{
        //clear all
        cy.get('.new-todo').type("Line the basket.{enter}");
        cy.get('.toggle').click();
        cy.contains('Clear').click();
        //cy.get('todo-list').should('not.have.descendants', 'li');
    })
})






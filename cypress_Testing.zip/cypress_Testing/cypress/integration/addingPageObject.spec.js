/// <reference types="cypress" />

const { TodoPage } = require("../page-objects/toDo-page")

//Regroup test Suite
describe('toDo action', () => {
    //instance the pageobject
    const todoPage = new TodoPage();

    beforeEach(() => {
        todoPage.navigate();
        todoPage.addTodo('Learning Cypress.');
    })

    it('should add a new toDo to the list ', () => {
        todoPage.validateTodoTxt(0, 'Learning Cypress.');
    })
    describe('toggling todos', () => {
        it('should toggle test correctly', () => {
          todoPage.toggleTodo(0)
          todoPage.validateTodoCompletedState(0, true)
        })
    
        it('should clear completed', () => {
          todoPage.toggleTodo(0)
          todoPage.clearCompleted()
          todoPage.validateNumberOfTodosShown(0)
        })
      })

})





